<?php

return [
    'name' => 'Students',
];
