<?php

namespace Modules\Students\Database\Seeders;

use Illuminate\Database\Seeder;

class StudentsDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
